<?php  

// incluye conexion 
require("conexion.php");


// Prepara el Query para la Inserción
$query  = " UPDATE mesas ";
$query .= " SET mesero = NULL";

// Ejecuta Query y obtiene Registros
$registros = $conexion->query($query);

// Verifica
if (!$registros)
{   
    // Devuelve el Error encontrado 
    $titulo      = "Error en Liberar Mesas";
    $descripcion = "[".$query."]".$conexion->error;
    $enlace      = "mesas.php";

    // Presenta ventana de Error
	header("Location: ../error.php?titulo=$titulo&descripcion=$descripcion&enlace=$enlace");
}   
else
{   
	// Variables para el error
    $titulo      = "Exito Liberar Mesas";
    $descripcion = "Se ha realizado con exito la Liberar Mesas";
    $enlace      = "mesas.php";

    // Lanzando Aplicación por Tipo
    header("Location: ../exito.php?titulo=$titulo&descripcion=$descripcion&enlace=$enlace");
}